1. Open the WINRAR you just opened.
2. Click and hold then when you see the plus, it helps you tell where you're going.
3.Go to Kade Engine/FNF Original game and look for data.
4. Click the song name and then hold it anywhere.
5. Then press ''OK''